export const firebaseConfig = {
  apiKey: "AIzaSyArPzeBS4dgT1r2_cl5PpVhLodD7nMJ6CI",
  authDomain: "rpg-tabletop-d5bad.firebaseapp.com",
  databaseURL: "https://rpg-tabletop-d5bad-default-rtdb.firebaseio.com",
  projectId: "rpg-tabletop-d5bad",
  storageBucket: "rpg-tabletop-d5bad.firebasestorage.app",
  messagingSenderId: "833228130381",
  appId: "1:833228130381:web:f2b131916f9b9f01ad3404",
  measurementId: "G-SSLMK665X5"
};
