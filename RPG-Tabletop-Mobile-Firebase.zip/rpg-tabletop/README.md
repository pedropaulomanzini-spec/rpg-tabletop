# RPG Tabletop — versão completa

Tabletop web multiplayer para sua campanha. Os mapas enviados estão em `maps/map_0.jpg` até `maps/map_11.jpg`.

## Recursos
- Sala por código e login anônimo.
- Mestre e jogadores em tempo real com Firebase Realtime Database.
- Mestre: painel completo de jogadores, HP, fichas, tokens, NPCs/monstros, áreas reveláveis, revelar/ocultar mapa e iniciativa.
- Jogadores: própria ficha, próprio token, HP, inventário, chat, dados e mapa revelado.
- Tokens arrastáveis e sincronizados.
- Tokens de jogador, NPC e monstro.
- Fotos para tokens via arquivo local ou URL.
- Ficha baseada no arquivo enviado: Nome, idade, aparência, lore, arquétipo, Saúde, Força, Agilidade, Inteligência, Percepção, Sorte e Sanidade. O modelo também informa que 1 ponto de Inteligência acrescenta 5 de sanidade máxima. fileciteturn0file0L1-L14
- Arquétipos do modelo: Herói, Atleta, Valentão, Patricinha, Inocente, Nerd, Maconheiro e Cético. fileciteturn0file0L15-L23
- Inventário com quantidade.
- Chat da mesa.
- Registro de eventos.
- Notas compartilhadas.
- Dados d4/d6/d8/d10/d12/d20.
- Zoom e movimentação do mapa.
- Ordem de iniciativa.
- Sistema de névoa por áreas.

## Colocar online
1. Crie um projeto em Firebase.
2. Ative Authentication > Sign-in method > Anonymous.
3. Crie Realtime Database.
4. Crie um app Web e copie a configuração para `firebase-config.js`.
5. Publique as regras de `database.rules.json` no Realtime Database.
6. Hospede a pasta em Firebase Hosting, Vercel, Netlify ou GitHub Pages.
7. O mestre cria uma sala e envia o código para os amigos.

## Fotos compartilhadas
O código já aceita fotos de token. Para uma versão totalmente online, a próxima etapa é ativar Firebase Storage e salvar as imagens como URLs públicas/privadas em vez de Data URL. Não coloque credenciais secretas no frontend.

## Estrutura
- `index.html`: interface.
- `style.css`: visual.
- `app.js`: lógica da mesa e sincronização.
- `firebase-config.js`: configuração do projeto Firebase.
- `database.rules.json`: regras de acesso.
- `maps/`: mapas da campanha.
